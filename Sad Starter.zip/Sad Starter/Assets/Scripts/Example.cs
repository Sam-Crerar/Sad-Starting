using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Example : MonoBehaviour
{
    public GameObject GameManager;
    public MasterHolder script;
    public Text text;
    // Start is called before the first frame update
    void Start()
    {
        script = GameManager.GetComponent<MasterHolder>();
    }

    // Update is called once per frame
    void Update()
    {
        text.text = script.points.ToString();
        if (Input.GetKeyDown(KeyCode.Space))
        {
            script.points += 10;
        }
    }
}
